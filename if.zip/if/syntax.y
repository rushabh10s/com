
%{
#include <stdio.h>
int yylex(void);
void yyerror(const char *s);
%}
%token IF ID NUM
%%
S : IF '(' E ')' '{' L '}' { printf("Valid Syntax\n"); } ;
L : L ST | ST ;
ST : ID '=' E ';' ;
E : E '+' E | E '*' E | E '<' E | '(' E ')' | ID | NUM ;
%%
int main() { return yyparse(); }
void yyerror(const char *s) { printf("Invalid Syntax\n"); }
