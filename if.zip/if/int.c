
#include <stdio.h>

int main()
{
    printf("SOURCE CODE:\n");
    printf("if (m < n * 4) {\n");
    printf("r = 16 * 5;\n");
    printf("s = x * y + z;\n");
    printf("t = m + s;\n}\n\n");

    printf("A) LEXICAL ANALYSIS\n");
    printf("Keyword: if\n");
    printf("Identifiers: m, n, r, s, x, y, z, t\n");
    printf("Numbers: 4, 16, 5\n");
    printf("Operators: <, *, =, +\n\n");

    printf("B) SYNTAX CHECKING\n");
    printf("Valid Syntax\n\n");

    printf("C) THREE ADDRESS CODE\n");
    printf("t1 = n * 4\n");
    printf("if m < t1 goto L1\n");
    printf("goto L2\n");
    printf("L1: t2 = 16 * 5\n");
    printf("r = t2\n");
    printf("t3 = x * y\n");
    printf("t4 = t3 + z\n");
    printf("s = t4\n");
    printf("t5 = m + s\n");
    printf("t = t5\n");
    printf("L2:\n\n");

    printf("D) CODE MOTION OPTIMIZATION\n");
    printf("t1 = n * 4\n");
    printf("t2 = 80\n");
    printf("t3 = x * y\n");
    printf("t4 = t3 + z\n");
    printf("if m < t1 goto L1\n");
    printf("goto L2\n");
    printf("L1: r = t2\n");
    printf("s = t4\n");
    printf("t5 = m + s\n");
    printf("t = t5\n");
    printf("L2:\n\n");

    printf("E) TARGET CODE GENERATION\n");
    printf("MOV R1, n\n");
    printf("MUL R1, #4\n");
    printf("MOV R2, #80\n");
    printf("MOV R3, x\n");
    printf("MUL R3, y\n");
    printf("ADD R3, z\n");
    printf("CMP m, R1\n");
    printf("JGE L2\n");
    printf("L1: MOV r, R2\n");
    printf("MOV s, R3\n");
    printf("MOV R4, m\n");
    printf("ADD R4, s\n");
    printf("MOV t, R4\n");
    printf("L2: HALT\n\n");

    printf("F) INTEGRATION AND VERIFICATION\n");
    printf("All modules verified successfully.\n");

    return 0;
}
