
%{
#include <stdio.h>
#include <string.h>
int yylex(void);
void yyerror(const char *s);
int temp = 0, label = 0, L1, L2;
%}
%union { char str[20]; }
%token IF
%token <str> ID NUM
%type <str> E
%left '+'
%left '*'
%%
S : IF '(' ID '<' E ')' {
        L1 = ++label; L2 = ++label;
        printf("if %s < %s goto L%d\n", $3, $5, L1);
        printf("goto L%d\nL%d:\n", L2, L1);
    }
    '{' STS '}' { printf("L%d:\n", L2); }
  ;
STS : STS ST | ST ;
ST : ID '=' E ';' { printf("%s = %s\n", $1, $3); } ;
E : E '+' E {
        sprintf($$, "t%d", ++temp);
        printf("%s = %s + %s\n", $$, $1, $3);
    }
  | E '*' E {
        sprintf($$, "t%d", ++temp);
        printf("%s = %s * %s\n", $$, $1, $3);
    }
  | ID { strcpy($$, $1); }
  | NUM { strcpy($$, $1); }
  ;
%%
int main() { return yyparse(); }
void yyerror(const char *s) { printf("Invalid syntax\n"); }
