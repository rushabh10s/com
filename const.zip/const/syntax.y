
%{
#include <stdio.h>
int yylex(void);
void yyerror(const char *s);
%}

%token ID NUM
%left '+'
%left '*'

%%
program : stmts { printf("Valid Syntax\n"); } ;
stmts   : stmts stmt | stmt ;
stmt    : ID '=' E ';' ;
E       : E '+' E
        | E '*' E
        | '(' E ')'
        | ID
        | NUM
        ;
%%
int main() { return yyparse(); }
void yyerror(const char *s) { printf("Invalid Syntax\n"); }
