
#include <stdio.h>

int main()
{
    printf("Optimized Three Address Code:\n");
    printf("a = 50\n");
    printf("b = 50\n");
    printf("t1 = a + b\n");
    printf("c = t1\n");

    return 0;
}
