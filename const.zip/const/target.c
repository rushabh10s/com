
#include <stdio.h>

int main()
{
    printf("Target Code:\n");
    printf("MOV a, #50\n");
    printf("MOV b, #50\n");
    printf("MOV R1, a\n");
    printf("ADD R1, b\n");
    printf("MOV c, R1\n");

    return 0;
}
