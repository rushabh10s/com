
%{
#include <stdio.h>
#include <string.h>
int yylex(void);
void yyerror(const char *s);
int temp = 0;
%}

%union { char str[20]; }
%token <str> ID NUM
%type <str> E
%left '+'
%left '*'

%%
program : stmts ;
stmts   : stmts stmt | stmt ;

stmt : ID '=' E ';'
       { printf("%s = %s\n", $1, $3); }
     ;

E : E '+' E
    {
        sprintf($$, "t%d", ++temp);
        printf("%s = %s + %s\n", $$, $1, $3);
    }
  | E '*' E
    {
        sprintf($$, "t%d", ++temp);
        printf("%s = %s * %s\n", $$, $1, $3);
    }
  | '(' E ')' { strcpy($$, $2); }
  | ID        { strcpy($$, $1); }
  | NUM       { strcpy($$, $1); }
  ;
%%
int main() { return yyparse(); }
void yyerror(const char *s) { printf("Invalid Syntax\n"); }
