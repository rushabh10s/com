
%{
#include <stdio.h>
#include <string.h>
int yylex(void);
void yyerror(const char *s);
int temp = 0, label = 0;
int start, body, end;
%}

%union { char str[20]; }
%token WHILE
%token <str> ID NUM
%type <str> expr
%left '+'
%left '*'

%%
program : stmt ;

stmt : WHILE '('
       { start = ++label; printf("L%d:\n", start); }
       expr '<' expr ')'
       { body = ++label; end = ++label;
         printf("if %s < %s goto L%d\n", $4, $6, body);
         printf("goto L%d\nL%d:\n", end, body); }
       '{' stmts '}'
       { printf("goto L%d\nL%d:\n", start, end); }
     | ID '=' expr ';'
       { printf("%s = %s\n", $1, $3); }
     ;

stmts : stmts stmt
      | stmt
      ;

expr : expr '+' expr
       { char t[20]; sprintf(t, "t%d", ++temp);
         printf("%s = %s + %s\n", t, $1, $3);
         strcpy($$, t); }
     | expr '*' expr
       { char t[20]; sprintf(t, "t%d", ++temp);
         printf("%s = %s * %s\n", t, $1, $3);
         strcpy($$, t); }
     | '(' expr ')' { strcpy($$, $2); }
     | ID           { strcpy($$, $1); }
     | NUM          { strcpy($$, $1); }
     ;
%%

int main() { return yyparse(); }
void yyerror(const char *s) { printf("Invalid syntax\n"); }
