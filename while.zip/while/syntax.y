
%{
#include <stdio.h>
int yylex();
int yyerror(char *s);
%}

%token WHILE ID NUM

%%
S : WHILE '(' E ')' '{' L '}' { printf("Valid Syntax\n"); }
  ;

L : L ST
  | ST
  ;

ST : ID '=' E ';'
   ;

E : E '+' E
  | E '*' E
  | E '<' E
  | '(' E ')'
  | ID
  | NUM
  ;
%%

int main()
{
    printf("Enter the input:\n");
    yyparse();
    return 0;
}

int yyerror(char *s)
{
    printf("Invalid Syntax\n");
    return 0;
}
