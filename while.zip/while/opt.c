
#include <stdio.h>

int main()
{
    printf("Optimized Three Address Code:\n");

    printf("t1 = n * 4\n");
    printf("t2 = 16 * 5\n");
    printf("t3 = x * y\n");
    printf("t4 = t3 + z\n");

    printf("L1: if m < t1 goto L2\n");
    printf("    goto L3\n");
    printf("L2: r = t2\n");
    printf("    s = t4\n");
    printf("    t5 = m + s\n");
    printf("    t = t5\n");
    printf("    goto L1\n");
    printf("L3:\n");

    return 0;
}
