
#include <stdio.h>

int main()
{
    printf("Target Code:\n");

    printf("MOV R1, n\n");
    printf("MUL R1, #4\n");
    printf("MOV R2, #80\n");
    printf("MOV R3, x\n");
    printf("MUL R3, y\n");
    printf("ADD R3, z\n");

    printf("L1: CMP m, R1\n");
    printf("JGE L3\n");
    printf("L2: MOV r, R2\n");
    printf("MOV s, R3\n");
    printf("MOV R4, m\n");
    printf("ADD R4, s\n");
    printf("MOV t, R4\n");
    printf("JMP L1\n");
    printf("L3: HALT\n");

    return 0;
}
